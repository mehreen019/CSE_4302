#ifndef SHAPE_H
#define SHAPE_H
#include<math.h>
#include<iostream>
using namespace std;

class shape
{
    public:
        shape();
        ~shape();

        void whoAmI();

    protected:

    private:

};

#endif // SHAPE_H
