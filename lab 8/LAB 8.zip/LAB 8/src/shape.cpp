#include "shape.h"

shape::shape()
{
    //ctor
}

shape::~shape(){

}
