#include "book.h"

book::book()
{
    //ctor
}

book::~book()
{
    //dtor
}
