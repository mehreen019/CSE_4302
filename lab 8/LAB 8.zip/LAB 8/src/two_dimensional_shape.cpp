#include "two_dimensional_shape.h"

two_dimensional_shape::two_dimensional_shape()
{

}

two_dimensional_shape::~two_dimensional_shape()
{
    //dtor
}
