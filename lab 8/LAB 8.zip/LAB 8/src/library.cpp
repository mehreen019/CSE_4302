#include "library.h"

library::library()
{
    //ctor
}

library::library(string name, string location, string working_hour):name(name), location(location), working_hour(working_hour)
{
    //ctor
}

void library::setData(){
    book temp;
    //temp.Setauthor()
}

library::~library()
{
    //dtor
}
