#include "three_dimensional_shape.h"

three_dimensional_shape::three_dimensional_shape()
{
    //ctor
}

three_dimensional_shape::~three_dimensional_shape()
{
    //dtor
}
