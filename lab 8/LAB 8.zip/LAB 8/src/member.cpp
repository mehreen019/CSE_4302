#include "member.h"

member::member()
{
    //ctor
}

member::~member()
{
    //dtor
}
